from .emotion_classifier import EmotionClassifier

__all__ = ['EmotionClassifier']
